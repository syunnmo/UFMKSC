function [L, W] = SimilarityFromFile(W)%改
    n = size(W,1);  %行数
    Dg = sum(W,2);  %行和
    Dg = Dg.^(0.5);
    DH = diag(1./Dg(Dg~=0));   %对角矩阵 
    AN = DH * W * DH;   %插乘：A*B（矩阵乘法）
    I = eye(n);
    L = I + AN;
    %DH = diag(Dg); % D矩阵
    %L = DH - W;
    W = AN;
end