function sil = silhouette(Dmat, kmclust)
    proxim = proximity(Dmat);
    K = max(kmclust);
    cl = (1:K);% seq(1:K)
    n = size(Dmat,1);
    s = zeros(1,n);%改vector(mode = "numeric", length = n);
    bvec = zeros(1,(K-1));%改vector(mode = "numeric", length = K - 1);
    for i = 1:n
        own = kmclust(i);
        temp = proxim(i,:);
        restown = setdiff((find(kmclust == own))', i);%which
        if(~isempty(restown))%if(length(restown)>0)
            owndist = temp(restown);
            ai = mean(owndist);
        else
            ai = 0;
        end
        oc = setdiff(cl, own);
        for j = 1:length(oc)
            oth = oc(j);
            otherclust = (find(kmclust == oth))';
            othdist = temp(otherclust);
            bvec(j) = mean(othdist);
        end
        bi = min(bvec);
        s(i) = (bi - ai) / max(ai, bi);
    end
    clustsil = zeros([1,K]);%clustsil = repmat(0,[1,K]);
    for i = 1:K
    	temp = (find(kmclust == i))';
        clsil = s(temp);
        clustsil(i) = mean(clsil);
    end
    sil = mean(s);
end