function proxim = proximity(Dmat)
    n = size(Dmat,1);
    proxim = zeros(n,n);
    for i = 1:n
        for j = 1:(i - 1)
            proxim(i, j) = sqrt(sumsq(Dmat(i,:), Dmat(j,:)));
            proxim(j, i) = proxim(i, j);
        end
    end
end

