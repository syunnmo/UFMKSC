function [Q, R] = gramschmidt(x)
    %x = as.matrix(x);
    n = size(x,2);  %列数
    m = size(x,1);  %行数
    q = zeros(m,n);
    r = zeros(n,n);
    for j = 1:n
        v = x(:,j);
        if(j>1)
            for i = 1:(j-1)
                r(i,j) = transpose(q(:,i)) * x(:,j);
                v = v - r(i,j) * q(:,i);
            end
        end
        r(j,j) = sqrt(sum(v.^2));
        q(:,j) = v / r(j,j);
    end
    Q = q;
    R = r;
end