function [U, Lstar, LLL, Alpha] = ConvexLaplacian_for_in(Data, K, alpha, rank)
M = length(Data);
if (~exist('rank','var'))
    startRk = ceil(K / M);
    maxRk = 50;
else
    maxRk = rank;
    startRk = maxRk;
end
step = 1;
nkmeans = 30;
rkSeq = (startRk:step:maxRk);
SilOpt = -1;
show = 5;
nstart = 100;
ShiLm_U = cell(1,M);
ShiLm_D = cell(1,M);
ShiLm_L = cell(1,M);
ShiLmperp = [];
Datas = cell(1,M);
Rel = [];
Alpha = [];
order = [];
Dist = [];
sigma = [];
n = size(Data{1},1);
for rkFrac = startRk:maxRk %小改�?
    nsc = rkFrac;
    evind = (1:nsc);
    for m = 1:M %1:M
        Lm = Data{m};
        [V, D] = eig(Lm);%V特征向量，D对角矩阵即特征�? 在这里直接使用对角矩阵没有用行向�?源代码是行向�?。eig是原来的，eigs是稀疏矩阵�?
        V = real(V);
        D = real(D);
        D = diag(D); %获取矩阵的主对角线上的元�?
%         [~,I] = sort(D,'descend'); % ����Ĭ�ϵ�������
%         V = V(:,I);
%         D = D(I);
        
        D(abs(D) < 1e-10) = 0;
        digits = 10;
        D = round(D, digits);
        evind = (find(D ~= 2))';
        evind = evind(1:nsc);
        ln = length(D(:));       
        Um = V(:, evind);
        Dm = D(evind);
%         Dmat = V(:, 2);
        ShiLm_U{m} = Um+eps;
        ShiLm_D{m} = Dm;
        ShiLm_L{m} = Lm;
    end
    Alpha = alpha;
    %%%%
    Gamma = cell(1,M);
    Gamma{1} = ShiLm_U{1};
    Basis = Gamma{1};
    for m = 2:M
        Sm = Basis' * ShiLm_U{m};
        Pm = Basis * Sm;
        Qm = ShiLm_U{m} - Pm;
        [Gm, ~] = gramschmidt(Qm);
        Gamma{m} = Gm;
        Basis = [Basis, Gm];
    end
    HmList = cell(1,M);
    for m = 1:M
        HmTemp = zeros(M * nsc, M * nsc);
        for p = 1:M
            for q = 1:M
                if(nsc == 1)
                    Blockpq = ((Gamma{p})') * ShiLm_U{m} * ShiLm_D{m} * ((ShiLm_U{m})') * Gamma{q};%%%%%%
                else
                    Blockpq = ((Gamma{p})') * ShiLm_U{m} * diag(ShiLm_D{m}) * ((ShiLm_U{m})') * Gamma{q};%%%%%%
                end
                Blockpq(abs(Blockpq) < 1e-10) = 0;
                rs = (p - 1) * nsc + 1;
                rl = (p - 1) * nsc + nsc;
                cs = (q - 1) * nsc + 1;
                cl = (q - 1) * nsc + nsc;
                HmTemp(rs:rl, cs:cl) = Blockpq;
            end
        end
        HmList{m} = HmTemp;
    end
    tkind = (1:K);
    H = zeros(M * nsc, M * nsc);
    for m = 1:M
        H = H + Alpha(m) * HmList{m};
        [a,b] = eig(HmList{m});
        a = a(:, tkind);
        b = b(tkind);
        c = Basis * a;
        LLL{m} = c * diag(b) * c';
    end
    [R, Pik] = eig(H);
    R = real(R);
    Pik = real(Pik);
%     Pik = diag(Pik);
%     [~,I]=sort(Pik,'descend');%����Ĭ�ϵ�������descend ascend
%     R = R(:,I);
%     Pik = Pik(I);

    R = R(:, tkind);
    Pik = Pik(tkind);
    Vk = Basis * R;
    LRstar = Vk * diag(Pik) * Vk';
    Lkstar = Vk;%%%%%%
    for i =1:size(Lkstar,2)
        nrm = sqrt(sum(Lkstar(:, i).^2));
        Lkstar(:,i) = Lkstar(:,i) / nrm;
    end
    Lkstar = real(Lkstar);
    km = kmeans(Lkstar, K);
    RankSil = silhouette(Lkstar, km);
    disp(["At rank r=",nsc]);
    disp(["Silhoutte index=",RankSil]);
    if (RankSil > SilOpt)
        VrOpt = Lkstar;
        PirOpt = Pik;
        SilOpt = RankSil;
        rStar = nsc;
        LOpt = LRstar;
    end
end
disp(["Optimal rank r*=",rStar]);
Lstar = LOpt;
U = VrOpt;
D = PirOpt;
Sil = SilOpt;
end
