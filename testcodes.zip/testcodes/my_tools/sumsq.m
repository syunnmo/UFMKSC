function eqd = sumsq(v1, v2)
    eqd = sum((v1 - v2).^2);
end
