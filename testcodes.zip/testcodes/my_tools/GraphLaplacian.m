function [L, W] = GraphLaplacian(Dmat, rbfsg, mod)%(Dmat, rbfsg = 1000, mod = 1)
    if (~exist('rbfsg','var'))
        rbfsg = 1000;
    end
    if (~exist('mod','var'))
        mod = 1;
    end
    n = size(Dmat,1);
    W = zeros(n,n);
    for i = 1:n
        for j = 1:i
            W(j, i) = exp(-sum((Dmat(i,:) - Dmat(j,:)).^2) / (2 * rbfsg * rbfsg));	%无向图,邻接矩阵 
            W(i, j) = W(j, i);
        end
    end
    Dg = sum(W,2);  %行和
    Dg = Dg.^(0.5);
    DH = diag(1./Dg(Dg~=0));   %对角矩阵 
    AN = DH * W * DH;   %插乘：A*B（矩阵乘法）
    I = eye(n);
    L = I + AN;
    %DH = diag(Dg); % D矩阵
    %L = DH - W;
    W = AN;
end
