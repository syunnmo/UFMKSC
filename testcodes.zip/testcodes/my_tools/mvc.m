function [ress,FV,Fstar, Yres,obj,i] = mvc(Data1, Data2, Data3, ker_num, cla_num, smp_num, Rk,ylabel,gamma,para3,para4)
%%order1; order2; order1+2; 模态数; 聚类数;  
%% initialization
% Initialize kernel weights
alpha = ones(ker_num,1) / ker_num;
% Initialize Fstar
Fstar = rand(size(Data2{1},1),cla_num);
Fstar = MGramSchmidt(Fstar);% Fstar = RandOrthhMat(n,c);
% Initialize R
R = eye(cla_num);
% Initialize T
T = eye(cla_num);
% initial Y of one 1 in each row
Ik = eye(cla_num);
randorder = randperm(size(Ik,1));
numceil = ceil(smp_num/cla_num);
largeY = repmat(Ik(randorder,:),numceil,1);% (size(A,1)*M, size(A,2)*N)
Yres = largeY(1:smp_num,:);% N*k
[~,res_label] = max(Yres,[],2);
% Initialize F{v} 每个视图的F{v}
FV = ConvexLaplacian(Data2, cla_num, alpha, Rk);
% FV = ConvexLaplacian_for_in(Data2, cla_num, alpha);
%% optimization
obj = zeros(1, 30);
MaxIter = 100; 
n = smp_num;
c = cla_num;
%% update alpha, Fstar, Y, R
for i=1:MaxIter
    fprintf(1, 'running iteration of the proposed algorithm %d...\n', i);
    resold = res_label;
    %% alpha
    for m=1:ker_num %生成v
        lambada(m,1)= -1 * trace(FV{m}'*Fstar+Fstar'*FV{m});
    end
    beta = 9;
    beta = beta+2;
    alpha=outuk1(lambada,beta,ker_num);
    %% F*
    SumFv = zeros(size(FV{1}));
    for num = 1:ker_num
        SumFv = SumFv + alpha(num) * FV{num}; % SumFv = SumFv + FV{num};
    end
    G = Yres.^gamma;
    FGR=2*para4*SumFv+G*R';
    
    [Uf,~,Vf] = svd(FGR,'econ');
    Fstar = Uf*Vf';
    
    %% R
    [Ur,~,Vr] = svd(Fstar'*G,'econ');
    R = Ur*Vr';
  
    %% updata Y
    E=zeros(n,c);
    for ei = 1:n
        for ec = 1:c
            E(ei,ec) = norm( T(ec,:) - Fstar(ei,:) * R , 2)^2;
        end
    end

    if gamma == 1
        for yi = 1:n
            [~,yindex]=min(E(yi,:));
            Yres(yi,yindex)=1;% n*c result
        end
        [~,res_label] = max(Yres,[],2);
    else
        Yup = E.^(1/(1-gamma)); % n × k
        Ydown = sum(Yup,2);% n × 1 //sum of a row
        Yres = Yup ./ repmat(Ydown,1,c); % n × k result
        
        [~, res_label] = max(Yres, [], 2);% 
    end
 
	%disp('After Y');
    obj(i,5)=cal_obj(smp_num,cla_num,ker_num,gamma,FV,Fstar,R,Yres,alpha);
   
    [ress(i,:)] = Clustering8Measure(ylabel,res_label);

% %     convergence
    objres(i) = norm(res_label - resold)/norm(resold);
    if i>5 && (norm(res_label - resold)/norm(resold)<1e-3)
        break
    end
end
end

function uk=outuk1(v,gama,M)%optimal w
[v,index]=sort(v);
v(M+1,1)=v(M,1);
for p=1:M  %求出p
    theta=(gama+sum(v(1:p,1)))/min(p,M);
    for i=1:M+1
        if theta-v(i,1)<=0
            break
        end
    end
    if p==i-1 
        break
    end
end
W=zeros(M,1);%Wm
for i=1:M
    if i<=p
        W(i,1)=(theta-v(i,1))/(gama);
    end
end
uk=W(index,1);
end
