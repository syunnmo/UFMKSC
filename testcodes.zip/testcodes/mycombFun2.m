function cF = mycombFun2(Y,gamma)
m = length(Y);
cF = zeros(size(Y{1},1),size(Y{1},2));
for p = 1:m
    cF = cF + Y{p}*gamma(p);
end
end

