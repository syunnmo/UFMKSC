clear
clc
warning off;
addpath(genpath('./ClusteringEvaluation'));
addpath(genpath('./my_tools'));
addpath(genpath('./comvsc'));
addpath(genpath('./MKC2020B'));
% path_data = '/home/matlab/work/datasets/MultipleKernelDatasets/';
path_data = 'G:/load/dataset/';
DataName = cell(1,10);
% DataName{1} = 'bbcsport';DataName{2} = 'proteinFold';DataName{3} = 'flower17';DataName{4} = 'caltech101_mit';
% DataName{5} = 'UCI_DIGIT';DataName{6} = 'mfeat';DataName{7} = 'flower102';DataName{8} = 'YALE';
% DataName{9} = 'CCV';DataName{10} = 'Reuters_';DataName{11} = 'AR10P';DataName{12} = 'SensITVehicle_1500sample_2view_3cluster';
% DataName{13} = 'washington';DataName{14} = 'caltech101_nTrain10_48';DataName{15} = 'caltech101_nTrain15_48';
% DataName{16} = 'caltech101_nTrain20_48';DataName{17} = 'wisconsin';DataName{18} = '';DataName{19} = 'caltech101_nTrain5_48';
% DataName{20} = 'texas';DataName{21} = 'cornell';DataName{22} = 'PIE10P';DataName{23} = 'ORL';
% DataName{24} = 'bbcsport2view';DataName{25} = 'Handwritten_numerals';

DataName{1} = 'SUNRGBD_fea';DataName{2} = 'Animal';DataName{3} = 'stl10_fea';DataName{4} = 'ALOI-100';

DataName{1} = 'WikipediaArticles';
DataName{2} = 'synthetic3d';
DataName{3} = 'ORL';
DataName{4} = 'NGs';
DataName{5} = 'prokaryotic';
for data_num =  2:5
    
    dataName = DataName{data_num};
    %% psortPos, psortNeg; plant
    load([path_data,dataName,'_Kmatrix'],'KH','Y');
    cla_num = length(unique(Y));
    ker_num = size(KH,3);
    smp_num = size(KH,1);
    res = zeros(2,3);
    gma = [0.9:0.2:3.5];
    para3=1;
    para4=1;
    idx = 1;
    
    
    KH = kcenter(KH);
    KH = knorm(KH);    
    
    
        
        %% local kernel construction 
    
%     for NNRate = 0.1:0.1:1 %1:10 
%         LowRankNum = round( NNRate * smp_num / cla_num );
%         %LowRankNum = round(NNRate * log2(smp_num)); % NeiNum = round( NNRate * smp_num / cla_num );
%         [KHL] = LocalKernelCalculationNew(KH , LowRankNum);

   for NNRate = [0.01:0.01:0.2,0.3]
        [KHL] = LocalKernelCalculation(KH , NNRate);

        %% Laplacian matrix generation
            for j=1:length(gma)
                [~, L2, ~] = V9_laplacian_generation(KHL,cla_num);
                Data1 = cell(1,ker_num);
                for m = 1:ker_num
                    Data1{m} = [];
                end
                Data2 = cell(1,ker_num);
                for m = 1:ker_num
                    Data2{m} = L2(:,:,m);
                end
                Data3 = cell(1,ker_num);
                for m = 1:ker_num
                    Data3{m} =[];
                end
                for Rk = ceil(cla_num / ker_num):55
                    tic;
                    [ress,FV,Fstar, Yres,obj,iter_num] = mvc(Data1, Data2, Data3, ker_num, cla_num, smp_num, Rk,Y,gma(j),para3,para4);
                    t(idx)=toc;
                    res_comvsc = ress(end,:);
                    Result_11COMVSC(idx,:) = [NNRate gma(j) Rk iter_num res_comvsc];
%                     disp(['  Para2 = ',num2str(gma(j)), '  ACC = ', num2str(res_comvsc(:,7)),'  Time = ',num2str(t(idx))]);
                    ourFscore(j)  = res_comvsc(1); ourPrecision(j) = res_comvsc(2); ourRecall(j) = res_comvsc(3);
                    ourNmi(j) = res_comvsc(4);ourAR(j) = res_comvsc(5); ourEntropy(j) = res_comvsc(6);
                    ourACC(j) = res_comvsc(7); ourPurity(j) = res_comvsc(8);
                    dlmwrite(['./', dataName, '.txt'], Result_11COMVSC(idx,:),'-append','delimiter','\t','newline','pc');
%                     result_obj(idx,:) = obj;
%                     dlmwrite(['./', dataName, '.txt'], result_obj(idx,:),'-append','delimiter','\t','newline','pc');
                    idx = idx+1;
                end
            end

    end
    maxresult = max(Result_11COMVSC,[],1);
    Allresult(1,:) = maxresult(3:10);
    fprintf('- Finish Proposed Method \n ');
    
    save(['./' , dataName ,'_Our.mat'], 't','Allresult');
end
% fclose(fid);